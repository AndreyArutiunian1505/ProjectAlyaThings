using Godot;
using System;

public class ScrollView : Control
{

    Control contentControl;
    
    private NodePath _content;
    [Export]
    public NodePath Content {
        get { return _content; }
        set {
            _content = value;
            Node getted = GetNode(_content);
            if (HasNode(_content) && getted is Control) {
                contentControl = getted as Control;
                RemoveChild(RightScrollBarContainer);
                AddChild(RightScrollBarContainer);
                RemoveChild(BottomScrollBarContainer);
                AddChild(BottomScrollBarContainer);
            }
        }
    }

    ///Размер контента. На основе этого ограничивается прокрутка
    public Vector2 ContentSize = new Vector2();

    [Export]
    public bool HorizontalScroll = true;

    [Export]
    public bool VerticalScroll = true;

    private Control RightScrollBarContainer, RightScrollBar, BottomScrollBarContainer, BottomScrollBar;
    private AnimationPlayer Animations;

    private bool ShowedBar = false;
    private Timer HideBarsTimer;

    public override void _Input(InputEvent @event) {
        if (@event is InputEventPanGesture && GetGlobalRect().HasPoint(GetGlobalMousePosition()) && contentControl != null) {
            InputEventPanGesture e = @event as InputEventPanGesture;
            Vector2 d = e.Delta;
            if (!HorizontalScroll) d.x = 0;
            if (!VerticalScroll)   d.y = 0;
            BottomScrollBar.Visible = HorizontalScroll;
            RightScrollBar.Visible = VerticalScroll;
            contentControl.RectPosition -= d * 4;
            if (!ShowedBar) {
                Animations.Play("Show");
                ShowedBar = true;
            }
            HideBarsTimer.Start();

            //Обновление баров
            RightScrollBar.RectSize = new Vector2(RightScrollBar.RectSize.x, RectSize.y * (RectSize.y / ContentSize.y) - 12*3);
            RightScrollBar.RectPosition = new Vector2(RightScrollBar.RectPosition.x, -contentControl.RectPosition.y * (RectSize.y / ContentSize.y)+12);

            BottomScrollBar.RectSize = new Vector2(RectSize.x * (RectSize.x / ContentSize.x) - 12*3, BottomScrollBar.RectSize.y);
            BottomScrollBar.RectPosition = new Vector2(-contentControl.RectPosition.x * (RectSize.x / ContentSize.x) + 12, BottomScrollBar.RectPosition.y);
        }
    }

    public override void _Ready() {
        if (_content != null)
            Content = _content;

        RightScrollBarContainer = GetNode("RightScrollBar") as Control;
        RightScrollBar = GetNode("RightScrollBar/Bar") as Control;
        BottomScrollBarContainer = GetNode("LeftScrollBar") as Control;
        BottomScrollBar = GetNode("LeftScrollBar/Bar") as Control;
        RemoveChild(RightScrollBarContainer);
        AddChild(RightScrollBarContainer);
        RemoveChild(BottomScrollBarContainer);
        AddChild(BottomScrollBarContainer);

        Animations = GetNode("Animation") as AnimationPlayer;
        HideBarsTimer = GetNode("HideBarsTimer") as Timer;
    }

    public override void _PhysicsProcess(float delta) {
        //Ограничение скролинга
        if (contentControl.RectPosition.y > 0) {
            contentControl.RectPosition = new Vector2(contentControl.RectPosition.x, contentControl.RectPosition.y - (contentControl.RectPosition.y) / 3 );
        }
        if (contentControl.RectPosition.x > 0) {
            contentControl.RectPosition = new Vector2(contentControl.RectPosition.x - (contentControl.RectPosition.x) / 3 , contentControl.RectPosition.y);
        }
        if (contentControl.RectPosition.y < -ContentSize.y + RectSize.y) {
            contentControl.RectPosition = new Vector2(contentControl.RectPosition.x, 
            ((ContentSize.y > RectSize.y) ? (contentControl.RectPosition.y - (contentControl.RectPosition.y - (-ContentSize.y + RectSize.y)) / 3) :
                                            (0)
            ));
        }
        if (contentControl.RectPosition.x < -ContentSize.x + RectSize.x) {
            contentControl.RectPosition = new Vector2(
                ((ContentSize.x > RectSize.x) ? (contentControl.RectPosition.x - (contentControl.RectPosition.x - (-ContentSize.x + RectSize.x)) / 3) : 
                                                (0)),
                contentControl.RectPosition.y);
        }
    }

    private void HideBarsTimer_Timeout() {
        if (ShowedBar) {
                Animations.PlayBackwards("Show");
                ShowedBar = false;
        }
    }

}
