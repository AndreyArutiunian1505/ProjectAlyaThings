using Godot;
using System;

public class EditableLabel : Label {
    public TextEdit Editor;
    private bool _isEditing = false;
    public bool IsEditing {
        get { return _isEditing; }
    }
    
    public override void _Ready() {
        Editor = GetNode("TextEdit") as TextEdit;
        Editor.SetClipContents(true);
    }
    
    public void StartEdit() {
        Editor.AddFontOverride("font", GetFont("font"));
        Editor.AddColorOverride("font_color", GetColor("font_color"));
        Editor.Text = Text;
        Editor.Show();
        Editor.Readonly = false;
        Editor.SelectAll();
        Editor.GrabFocus();
        _isEditing = true;
    }

    public void StopEdit() {
        Text = Editor.GetLine(0);
        Editor.Readonly = true;
        Editor.Hide();
        _isEditing = false;
    }

    public override void _Input(InputEvent @event) {
        if (@event is InputEventMouseButton) {
            Vector2 MousePos = GetGlobalMousePosition();
            Rect2 GlobalRect = GetGlobalRect();
            if (GlobalRect.HasPoint(MousePos)) {
                if ((@event as InputEventMouseButton).Doubleclick && !IsEditing) {
                    StartEdit();
                }          
            } else {
                if (IsEditing)
                    StopEdit();
            }

        }
        if (@event.IsAction("ui_accept") && !@event.IsPressed() && IsEditing) {
            StopEdit();
        }
            
    }

}
