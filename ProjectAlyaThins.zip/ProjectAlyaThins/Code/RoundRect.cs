using Godot;
using System;

public class RoundRect : Control
{
    private Texture[] Textures = new Texture[4] {
        ResourceLoader.Load("res://Images/RoundRect/RoundTopLeft.png") as Texture,
        ResourceLoader.Load("res://Images/RoundRect/RoundTopRight.png") as Texture,
        ResourceLoader.Load("res://Images/RoundRect/RoundBottomLeft.png") as Texture,
        ResourceLoader.Load("res://Images/RoundRect/RoundBottomRight.png") as Texture
    };

    public override void _Draw() {
        DrawTexture(Textures[0], new Vector2(0, 0));
        DrawTexture(Textures[1], new Vector2(RectSize.x-3, 0));
        DrawTexture(Textures[2], new Vector2(0, RectSize.y-3));
        DrawTexture(Textures[3], new Vector2(RectSize.x-3, RectSize.y-3));
        DrawRect(new Rect2(3, 0, RectSize.x-6, RectSize.y), new Color(1,1,1,1));
        DrawRect(new Rect2(0, 3, 3, RectSize.y-6), new Color(1,1,1,1));
        if (RectSize.x < 6)
            DrawRect(new Rect2(RectSize.x-2, 3, 2, RectSize.y-6), new Color(1,1,1,1));
        else
            DrawRect(new Rect2(RectSize.x-3, 3, 3, RectSize.y-6), new Color(1,1,1,1));
    }
}
