using Godot;
using System;
using System.Collections.Generic;
public class MenuView : Control {
    private Label tagLabel = new Label();
    private Control Menu = new Control();
    public List<EditableLabel> canvases = new List<EditableLabel>();
    public EditableLabel newCanvas;
    float canvasY = 0;
    float tagY = 0;
    public PackedScene EditableLabelScene;

    public override void _Ready() {
        EditableLabelScene = GD.Load("res://Objects/EditableLabel.tscn") as PackedScene;  
        //GW2480
    }
    private void AddCanvas() {
        newCanvas = EditableLabelScene.Instance() as EditableLabel;
        canvases.Add(newCanvas);
        if (newCanvas == canvases[0]) {
            canvasY = 40;
        } else {
            canvasY += 40 + (canvases[canvases.Count - 2].RectSize.y);
        } 
        newCanvas.RectPosition = new Vector2(30, canvasY);
        AddChild(newCanvas);  
        newCanvas.StartEdit();
    }
    private void AddCanvas_Click() {  
        AddCanvas();
    }

    public override void _Process(float delta) {
        for (int i = 0; i < canvases.Count; i++) {
            
        }
    }


}
