using Godot;
using System;

public class Canvas: Control
{
    private LineEdit le;

    ///Load object
    public override void _Ready()
    {
        //Get line edit at our canvas
        LineEdit le = GetNode("LineEdit") as LineEdit;

        //Configure line edit 
        le.SetPosition(new Vector2(30, 10));
        le.SetSize(new Vector2(180, 10));
    }

    ///Create new Label insted of LineEdit
    public void CreateLabel()
    {
        //Create label
        Label l = new Label();

        LineEdit le = GetNode("LineEdit") as LineEdit;
        
        GD.Print("[DEBUG] ", l, " ", le);
        //Configure new label with settings of line edit
        l.SetPosition(le.GetPosition() + new Vector2(0, 3));
        l.SetSize(le.GetSize());

        //Simple configure label
        l.Autowrap = true;
        l.Text = le.Text;

        //Hide line edit
        le.Hide();

        //Add label to tree
        this.AddChild(l);
    }
    
    ///Check all input events
    public override void _Input(InputEvent @event) {

        //Check if enter was pressed, then i am create new label instead of line edit
        if (@event.IsAction("ui_accept") && !@event.IsPressed())
        {
            //Create label
            CreateLabel();
        }
    }
}
